#import <Flutter/Flutter.h>

@interface BeaconPlugin : NSObject<FlutterPlugin>
@end
