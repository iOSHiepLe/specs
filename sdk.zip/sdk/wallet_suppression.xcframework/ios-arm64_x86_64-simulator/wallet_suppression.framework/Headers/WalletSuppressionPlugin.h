#import <Flutter/Flutter.h>

@interface WalletSuppressionPlugin : NSObject<FlutterPlugin>
@end
