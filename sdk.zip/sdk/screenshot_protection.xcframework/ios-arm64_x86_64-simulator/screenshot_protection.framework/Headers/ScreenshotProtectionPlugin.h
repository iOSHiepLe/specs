#import <Flutter/Flutter.h>

@interface ScreenshotProtectionPlugin : NSObject<FlutterPlugin>
@end
