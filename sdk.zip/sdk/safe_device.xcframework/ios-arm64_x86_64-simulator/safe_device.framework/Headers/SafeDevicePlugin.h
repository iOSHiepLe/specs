#import <Flutter/Flutter.h>

@interface SafeDevicePlugin : NSObject<FlutterPlugin>
@end
